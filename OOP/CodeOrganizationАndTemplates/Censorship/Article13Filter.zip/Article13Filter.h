#ifndef ARTICLE_13_FILTER_H
#define ARTICLE_13_FILTER_H

#include <string>
#include <vector>
#include <set>

class Article13Filter {
private:
	std::set<std::string> copyrighted;
	std::vector<std::string> blocked;
public:
	Article13Filter(std::set<std::string> copyrighted)
		: copyrighted(copyrighted) {}

	bool blockIfCopyrighted(const std::string s)
	{
		if (isCopyrighted(s)) {
			blocked.push_back(s);
			return true;
		}

		return false;
	}
	bool isCopyrighted(const std::string& s) const {
		return copyrighted.find(s) != copyrighted.end();
	}

	std::vector<std::string> getBlocked() {
		return blocked;
	}
};

#endif // !ARTICLE_13_FILTER_H

