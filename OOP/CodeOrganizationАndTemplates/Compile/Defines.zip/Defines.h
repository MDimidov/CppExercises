//Compile
//You are given some code, which reads a single string from the input and writes it to the output without any changes.
//The code however doesn�t compile.Figure out what file(s) needs to be created, and what file it needs to contain, so that the program compiles and runs as described.
//You should submit a single.zip file for this task, containing ONLY the file(s) YOU created.The Judge system has a copy of the other files and will compile them, along with your file, in the same directory.


#pragma once
#ifndef DEFINES_H
#define DEFINES_H
#define DONT_COMPILE_THIS
#define STANDARD_TEMPLATE_LIBRARY namespace std;

#include<iostream>
#include<string>

using namespace std;

#endif // !DEFINES_H
